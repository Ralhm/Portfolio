WS-Select Up/Down (you can also select which party member you wish to act in whatever order you want)
Left Click-Interact/Confirm
ABXY-Quck time event
